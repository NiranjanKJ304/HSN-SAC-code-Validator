import streamlit as st
import pandas as pd
import re
import io
from typing import List, Dict, Tuple, Optional, Union

# Initialize session state variables if they don't exist
if 'hsn_data' not in st.session_state:
    st.session_state.hsn_data = None
if 'sac_data' not in st.session_state:
    st.session_state.sac_data = None
if 'loaded_files' not in st.session_state:
    st.session_state.loaded_files = False

class HSNValidator:
    def __init__(self):
        # Use session state instead of instance variables
        pass
    
    def load_sample_data(self):
        """Load sample HSN and SAC data for demonstration"""
        # Sample HSN data
        hsn_data = {
            'HSNCode': ['01', '0101', '01011010', '01011020', '01011090', '010121', '01012100', '010129', '01012910'],
            'Description': [
                'LIVE ANIMALS', 
                'LIVE HORSES, ASSES, MULES AND HINNIES.', 
                'LIVE HORSES, ASSES, MULES AND HINNIES PURE-BRED BREEDING ANIMALS HORSES',
                'LIVE HORSES, ASSES, MULESANDHINNIES PURE-BRED BREEDING ANIMALS ASSES',
                'LIVE HORSES, ASSES, MULES AND HINNIES PURE-BRED BREEDING ANIMAL S OTHER',
                'PURE-BRED BREEDING ANIMALS',
                'PURE-BRED BREEDING ANIMALS',
                'other',
                'Horses for polo'
            ]
        }
        
        # Sample SAC data
        sac_data = {
            'SAC_CD': ['99', '9954', '995411', '995412', '995413', '995414', '995415', '995416', '995417'],
            'SAC_Description': [
                'All Services',
                'Construction services',
                'Construction services of affordable residential apartments by a promoter in a Residential Real Estate Project...',
                'Construction services of residential apartments other than affordable residential apartments...',
                'Construction services of commercial apartments by a promoter in a Residential Real Estate Project...',
                'Construction of a residential apartment by a promoter in an ongoing project...',
                'Construction services of residential apartments by a promoter in an ongoing project...',
                'Construction services of single dwelling, multi dwelling, multi-storied residential buildings...',
                'Construction services of commercial buildings such as office buildings, exhibition and marriage halls...'
            ]
        }
        
        st.session_state.hsn_data = pd.DataFrame(hsn_data)
        st.session_state.sac_data = pd.DataFrame(sac_data)
        st.session_state.loaded_files = True
        return True
    
    def load_data(self, hsn_file=None, sac_file=None):
        """Load HSN and SAC data from uploaded files"""
        if hsn_file is not None:
            try:
                hsn_data = pd.read_excel(hsn_file)
                # Ensure proper column names
                if 'HSNCode' not in hsn_data.columns or 'Description' not in hsn_data.columns:
                    potential_hsn_cols = [col for col in hsn_data.columns if 'hsn' in col.lower() or 'code' in col.lower()]
                    potential_desc_cols = [col for col in hsn_data.columns if 'desc' in col.lower()]
                    
                    if potential_hsn_cols and potential_desc_cols:
                        hsn_data = hsn_data.rename(columns={
                            potential_hsn_cols[0]: 'HSNCode',
                            potential_desc_cols[0]: 'Description'
                        })
                    else:
                        st.error("HSN file must contain 'HSNCode' and 'Description' columns")
                        return False
                
                # Convert HSNCode to string to ensure proper comparisons
                hsn_data['HSNCode'] = hsn_data['HSNCode'].astype(str)
                st.session_state.hsn_data = hsn_data
                
            except Exception as e:
                st.error(f"Error loading HSN file: {e}")
                return False
        
        if sac_file is not None:
            try:
                sac_data = pd.read_excel(sac_file)
                # Ensure proper column names
                if 'SAC_CD' not in sac_data.columns or 'SAC_Description' not in sac_data.columns:
                    potential_sac_cols = [col for col in sac_data.columns if 'sac' in col.lower() or 'code' in col.lower()]
                    potential_desc_cols = [col for col in sac_data.columns if 'desc' in col.lower()]
                    
                    if potential_sac_cols and potential_desc_cols:
                        sac_data = sac_data.rename(columns={
                            potential_sac_cols[0]: 'SAC_CD',
                            potential_desc_cols[0]: 'SAC_Description'
                        })
                    else:
                        st.error("SAC file must contain 'SAC_CD' and 'SAC_Description' columns")
                        return False
                
                # Convert SAC_CD to string to ensure proper comparisons
                sac_data['SAC_CD'] = sac_data['SAC_CD'].astype(str)
                st.session_state.sac_data = sac_data
                
            except Exception as e:
                st.error(f"Error loading SAC file: {e}")
                return False
        
        st.session_state.loaded_files = True
        return True

    def validate_format(self, code: str, code_type: str = 'HSN') -> bool:
        """
        Validates if the code has the correct format
        
        Args:
            code: The code to validate
            code_type: Either 'HSN' or 'SAC'
            
        Returns:
            bool: True if format is valid, False otherwise
        """
        # Remove any whitespace
        code = code.strip()
        
        # Basic format validation
        if not code:
            return False
        
        # HSN codes should be numeric and typically 2 to 8 digits
        if code_type == 'HSN':
            return bool(re.match(r'^\d{1,8}$', code))
        
        # SAC codes should be numeric and typically 2 to 6 digits
        elif code_type == 'SAC':
            return bool(re.match(r'^\d{1,6}$', code))
        
        return False

    def validate_existence(self, code: str, code_type: str = 'HSN') -> bool:
        """
        Validates if the code exists in the dataset
        
        Args:
            code: The code to validate
            code_type: Either 'HSN' or 'SAC'
            
        Returns:
            bool: True if code exists, False otherwise
        """
        if not st.session_state.loaded_files:
            return False
        
        # Remove any whitespace
        code = code.strip()
        
        if code_type == 'HSN':
            if st.session_state.hsn_data is None:
                return False
            return code in st.session_state.hsn_data['HSNCode'].values
        
        elif code_type == 'SAC':
            if st.session_state.sac_data is None:
                return False
            return code in st.session_state.sac_data['SAC_CD'].values
        
        return False

    def get_description(self, code: str, code_type: str = 'HSN') -> str:
        """
        Get the description for a valid code
        
        Args:
            code: The code to retrieve description for
            code_type: Either 'HSN' or 'SAC'
            
        Returns:
            str: Description of the code if found, empty string otherwise
        """
        if not st.session_state.loaded_files:
            return ""
        
        # Remove any whitespace
        code = code.strip()
        
        if code_type == 'HSN':
            if st.session_state.hsn_data is None:
                return ""
            matches = st.session_state.hsn_data[st.session_state.hsn_data['HSNCode'] == code]
            if not matches.empty:
                return matches.iloc[0]['Description']
        
        elif code_type == 'SAC':
            if st.session_state.sac_data is None:
                return ""
            matches = st.session_state.sac_data[st.session_state.sac_data['SAC_CD'] == code]
            if not matches.empty:
                return matches.iloc[0]['SAC_Description']
        
        return ""

    def validate_hierarchical(self, code: str, code_type: str = 'HSN') -> Dict[str, bool]:
        """
        Validate if the parent codes of a given code exist in the dataset
        
        Args:
            code: The code to validate hierarchically
            code_type: Either 'HSN' or 'SAC'
            
        Returns:
            Dict: Dictionary with parent codes as keys and boolean existence as values
        """
        result = {}
        
        if not st.session_state.loaded_files or len(code) <= 2:
            return result
        
        # Generate parent codes
        parent_codes = []
        if code_type == 'HSN':
            # For HSN, typically check 2, 4, 6 digit parents
            for i in range(2, len(code), 2):
                if i <= len(code):
                    parent_codes.append(code[:i])
        else:
            # For SAC, check 2, 4, 5, 6 digit parents
            lengths = [2, 4, 5, 6]
            for i in lengths:
                if i < len(code):
                    parent_codes.append(code[:i])
        
        # Check existence of each parent code
        for parent in parent_codes:
            result[parent] = self.validate_existence(parent, code_type)
            
        return result

    def validate_codes(self, codes: Union[str, List[str]], code_type: str = 'HSN') -> List[Dict]:
        """
        Validate a list of codes
        
        Args:
            codes: Single code string or list of code strings
            code_type: Either 'HSN' or 'SAC'
            
        Returns:
            List[Dict]: List of dictionaries with validation results
        """
        if isinstance(codes, str):
            # Handle single code input
            codes = [code.strip() for code in codes.split(',')]
        
        results = []
        
        for code in codes:
            code = code.strip()
            if not code:
                continue
                
            result = {
                'code': code,
                'code_type': code_type,
                'format_valid': self.validate_format(code, code_type),
                'exists': False,
                'description': '',
                'hierarchy': {}
            }
            
            if result['format_valid']:
                result['exists'] = self.validate_existence(code, code_type)
                
                if result['exists']:
                    result['description'] = self.get_description(code, code_type)
                    # Only check hierarchy for valid codes
                    result['hierarchy'] = self.validate_hierarchical(code, code_type)
            
            results.append(result)
            
        return results

    def get_statistics(self, code_type: str = 'HSN') -> Dict:
        """
        Get statistics about the loaded dataset
        
        Args:
            code_type: Either 'HSN' or 'SAC'
            
        Returns:
            Dict: Statistics about the dataset
        """
        stats = {
            'total_codes': 0,
            'code_length_distribution': {},
            'sample_codes': []
        }
        
        if not st.session_state.loaded_files:
            return stats
        
        df = st.session_state.hsn_data if code_type == 'HSN' else st.session_state.sac_data
        code_col = 'HSNCode' if code_type == 'HSN' else 'SAC_CD'
        
        if df is None or code_col not in df.columns:
            return stats
        
        stats['total_codes'] = len(df)
        
        # Get code length distribution
        df['code_length'] = df[code_col].astype(str).str.len()
        length_counts = df['code_length'].value_counts().to_dict()
        stats['code_length_distribution'] = {str(k): int(v) for k, v in length_counts.items()}
        
        # Get some sample codes
        if len(df) > 0:
            sample_size = min(5, len(df))
            stats['sample_codes'] = df.sample(sample_size)[code_col].tolist()
        
        return stats


def main():
    st.set_page_config(
        page_title="HSN/SAC Code Validator",
        page_icon="✅",
        layout="wide"
    )
    
    st.title("HSN/SAC Code Validator")
    st.write("""
    This application validates Harmonized System Nomenclature (HSN) codes and Service Accounting Codes (SAC) 
    based on master datasets. Upload your master files or use sample data to get started.
    """)
    
    # Initialize validator
    validator = HSNValidator()
    
    # Display current state information for debugging
    # Comment these lines in production
    if st.sidebar.checkbox("Show Debug Info", False):
        st.sidebar.write("Session State Contents:")
        st.sidebar.write(f"Loaded Files: {st.session_state.loaded_files}")
        st.sidebar.write(f"HSN Data: {'Loaded' if st.session_state.hsn_data is not None else 'None'}")
        st.sidebar.write(f"SAC Data: {'Loaded' if st.session_state.sac_data is not None else 'None'}")
    
    # Create tabs for different functionalities
    tab1, tab2, tab3, tab4 = st.tabs(["Data Loading", "Code Validation", "Batch Validation", "Dataset Analytics"])
    
    # Tab 1: Data Loading
    with tab1:
        st.header("Load Master Data")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Upload Files")
            hsn_file = st.file_uploader("Upload HSN Master Excel File", type=['xlsx', 'xls'], key="hsn_file_upload")
            sac_file = st.file_uploader("Upload SAC Master Excel File", type=['xlsx', 'xls'], key="sac_file_upload")
            
            if st.button("Load Uploaded Files"):
                if hsn_file is not None or sac_file is not None:
                    success = validator.load_data(hsn_file, sac_file)
                    if success:
                        st.success("Files loaded successfully!")
                    else:
                        st.error("Error loading files. Please check the format.")
                else:
                    st.warning("Please upload at least one file.")
            
        with col2:
            st.subheader("Use Sample Data")
            st.write("Don't have files? Use our sample data for demonstration.")
            if st.button("Load Sample Data"):
                success = validator.load_sample_data()
                if success:
                    st.success("Sample data loaded successfully!")
                else:
                    st.error("Error loading sample data.")

        # Display loaded data
        if st.session_state.loaded_files:
            st.subheader("Loaded HSN Data")
            if st.session_state.hsn_data is not None:
                st.dataframe(st.session_state.hsn_data.head(10))
                st.write(f"Total HSN codes: {len(st.session_state.hsn_data)}")
            else:
                st.info("No HSN data loaded")
                
            st.subheader("Loaded SAC Data")
            if st.session_state.sac_data is not None:
                st.dataframe(st.session_state.sac_data.head(10))
                st.write(f"Total SAC codes: {len(st.session_state.sac_data)}")
            else:
                st.info("No SAC data loaded")

    # Tab 2: Code Validation
    with tab2:
        st.header("Validate Individual Codes")
        
        if not st.session_state.loaded_files:
            st.warning("Please load data first in the 'Data Loading' tab.")
        else:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("HSN Code Validation")
                hsn_code = st.text_input("Enter HSN Code to validate", placeholder="e.g., 01011010")
                
                if st.button("Validate HSN Code"):
                    if hsn_code:
                        results = validator.validate_codes(hsn_code, 'HSN')
                        if results:
                            result = results[0]
                            
                            if not result['format_valid']:
                                st.error(f"❌ Invalid HSN Code Format: {hsn_code}")
                                st.write("HSN codes should be numeric and typically 2 to 8 digits.")
                            elif not result['exists']:
                                st.warning(f"⚠️ HSN Code Not Found: {hsn_code}")
                                st.write("The code format is valid but doesn't exist in the master data.")
                            else:
                                st.success(f"✅ Valid HSN Code: {hsn_code}")
                                st.write(f"**Description:** {result['description']}")
                                
                                # Show hierarchy results
                                if result['hierarchy']:
                                    st.subheader("Hierarchical Validation")
                                    hierarchy_data = []
                                    for parent, exists in result['hierarchy'].items():
                                        status = "✅ Found" if exists else "❌ Missing"
                                        description = validator.get_description(parent, 'HSN') if exists else ""
                                        hierarchy_data.append({"Parent Code": parent, "Status": status, "Description": description})
                                    
                                    st.table(pd.DataFrame(hierarchy_data))
                    else:
                        st.warning("Please enter an HSN code.")
            
            with col2:
                st.subheader("SAC Code Validation")
                sac_code = st.text_input("Enter SAC Code to validate", placeholder="e.g., 995411")
                
                if st.button("Validate SAC Code"):
                    if sac_code:
                        results = validator.validate_codes(sac_code, 'SAC')
                        if results:
                            result = results[0]
                            
                            if not result['format_valid']:
                                st.error(f"❌ Invalid SAC Code Format: {sac_code}")
                                st.write("SAC codes should be numeric and typically 2 to 6 digits.")
                            elif not result['exists']:
                                st.warning(f"⚠️ SAC Code Not Found: {sac_code}")
                                st.write("The code format is valid but doesn't exist in the master data.")
                            else:
                                st.success(f"✅ Valid SAC Code: {sac_code}")
                                st.write(f"**Description:** {result['description']}")
                                
                                # Show hierarchy results
                                if result['hierarchy']:
                                    st.subheader("Hierarchical Validation")
                                    hierarchy_data = []
                                    for parent, exists in result['hierarchy'].items():
                                        status = "✅ Found" if exists else "❌ Missing"
                                        description = validator.get_description(parent, 'SAC') if exists else ""
                                        hierarchy_data.append({"Parent Code": parent, "Status": status, "Description": description})
                                    
                                    st.table(pd.DataFrame(hierarchy_data))
                    else:
                        st.warning("Please enter a SAC code.")

    # Tab 3: Batch Validation
    with tab3:
        st.header("Batch Validation")
        
        if not st.session_state.loaded_files:
            st.warning("Please load data first in the 'Data Loading' tab.")
        else:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("HSN Batch Validation")
                hsn_batch = st.text_area("Enter HSN Codes (comma or newline separated)", 
                                         height=150, 
                                         placeholder="e.g., 01, 0101, 01011010")
                
                hsn_file_upload = st.file_uploader("Or upload file with HSN codes", type=['txt', 'csv'])
                
                if st.button("Validate HSN Batch"):
                    codes = []
                    
                    if hsn_batch:
                        # Handle text area input
                        lines = hsn_batch.split('\n')
                        for line in lines:
                            codes.extend([code.strip() for code in line.split(',') if code.strip()])
                    
                    if hsn_file_upload:
                        # Handle file upload
                        content = hsn_file_upload.getvalue().decode('utf-8')
                        lines = content.split('\n')
                        for line in lines:
                            codes.extend([code.strip() for code in line.split(',') if code.strip()])
                    
                    if codes:
                        results = validator.validate_codes(codes, 'HSN')
                        
                        # Create dataframe for display
                        df_results = []
                        for r in results:
                            status = "Valid" if r['format_valid'] and r['exists'] else "Invalid"
                            reason = ""
                            if not r['format_valid']:
                                reason = "Invalid format"
                            elif not r['exists']:
                                reason = "Code not found"
                                
                            df_results.append({
                                "Code": r['code'],
                                "Status": status,
                                "Reason": reason,
                                "Description": r['description']
                            })
                        
                        st.dataframe(pd.DataFrame(df_results))
                        
                        # Summary
                        valid_count = sum(1 for r in results if r['format_valid'] and r['exists'])
                        st.write(f"Total: {len(results)}, Valid: {valid_count}, Invalid: {len(results) - valid_count}")
                        
                        # Download results
                        df_download = pd.DataFrame(df_results)
                        csv = df_download.to_csv(index=False)
                        st.download_button(
                            "Download Results",
                            csv,
                            "hsn_validation_results.csv",
                            "text/csv",
                            key='download-hsn-csv'
                        )
                    else:
                        st.warning("Please enter HSN codes or upload a file.")
            
            with col2:
                st.subheader("SAC Batch Validation")
                sac_batch = st.text_area("Enter SAC Codes (comma or newline separated)", 
                                         height=150, 
                                         placeholder="e.g., 99, 9954, 995411")
                
                sac_file_upload = st.file_uploader("Or upload file with SAC codes", type=['txt', 'csv'])
                
                if st.button("Validate SAC Batch"):
                    codes = []
                    
                    if sac_batch:
                        # Handle text area input
                        lines = sac_batch.split('\n')
                        for line in lines:
                            codes.extend([code.strip() for code in line.split(',') if code.strip()])
                    
                    if sac_file_upload:
                        # Handle file upload
                        content = sac_file_upload.getvalue().decode('utf-8')
                        lines = content.split('\n')
                        for line in lines:
                            codes.extend([code.strip() for code in line.split(',') if code.strip()])
                    
                    if codes:
                        results = validator.validate_codes(codes, 'SAC')
                        
                        # Create dataframe for display
                        df_results = []
                        for r in results:
                            status = "Valid" if r['format_valid'] and r['exists'] else "Invalid"
                            reason = ""
                            if not r['format_valid']:
                                reason = "Invalid format"
                            elif not r['exists']:
                                reason = "Code not found"
                                
                            df_results.append({
                                "Code": r['code'],
                                "Status": status,
                                "Reason": reason,
                                "Description": r['description']
                            })
                        
                        st.dataframe(pd.DataFrame(df_results))
                        
                        # Summary
                        valid_count = sum(1 for r in results if r['format_valid'] and r['exists'])
                        st.write(f"Total: {len(results)}, Valid: {valid_count}, Invalid: {len(results) - valid_count}")
                        
                        # Download results
                        df_download = pd.DataFrame(df_results)
                        csv = df_download.to_csv(index=False)
                        st.download_button(
                            "Download Results",
                            csv,
                            "sac_validation_results.csv",
                            "text/csv",
                            key='download-sac-csv'
                        )
                    else:
                        st.warning("Please enter SAC codes or upload a file.")

    # Tab 4: Dataset Analytics
    with tab4:
        st.header("Dataset Analytics")
        
        if not st.session_state.loaded_files:
            st.warning("Please load data first in the 'Data Loading' tab.")
        else:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("HSN Dataset Analysis")
                
                if st.session_state.hsn_data is not None:  # Fixed line: use st.session_state instead of validator.hsn_data
                    hsn_stats = validator.get_statistics('HSN')
                    
                    st.write(f"**Total HSN Codes:** {hsn_stats['total_codes']}")
                    
                    # Code length distribution
                    st.write("**Code Length Distribution:**")
                    lengths = hsn_stats['code_length_distribution']
                    if lengths:
                        # Convert to dataframe for display
                        length_df = pd.DataFrame({
                            'Length': list(lengths.keys()),
                            'Count': list(lengths.values())
                        })
                        length_df = length_df.sort_values('Length')
                        
                        # Plot
                        st.bar_chart(length_df.set_index('Length'))
                        
                        # Table
                        st.table(length_df)
                else:
                    st.info("No HSN data loaded")
            
            with col2:
                st.subheader("SAC Dataset Analysis")
                
                if st.session_state.sac_data is not None:  # Fixed line: use st.session_state instead of validator.sac_data
                    sac_stats = validator.get_statistics('SAC')
                    
                    st.write(f"**Total SAC Codes:** {sac_stats['total_codes']}")
                    
                    # Code length distribution
                    st.write("**Code Length Distribution:**")
                    lengths = sac_stats['code_length_distribution']
                    if lengths:
                        # Convert to dataframe for display
                        length_df = pd.DataFrame({
                            'Length': list(lengths.keys()),
                            'Count': list(lengths.values())
                        })
                        length_df = length_df.sort_values('Length')
                        
                        # Plot
                        st.bar_chart(length_df.set_index('Length'))
                        
                        # Table
                        st.table(length_df)
                else:
                    st.info("No SAC data loaded")

    # Footer
    st.sidebar.header("About")
    st.sidebar.info("""
    ### HSN/SAC Code Validator
    
    This application helps validate Harmonized System Nomenclature (HSN) codes and Service Accounting Codes (SAC) 
    according to master datasets.
    
    **Features:**
    - Individual code validation
    - Batch validation
    - Dataset analysis
    - Hierarchical validation
    
    **HSN Codes:** International standardized system of names and numbers to classify traded products.
    
    **SAC Codes:** Service Accounting Codes used for classifying services for taxation purposes.
    """)
    
    st.sidebar.header("Usage Instructions")
    st.sidebar.info("""
    1. **Load Data:** 
       - Upload your HSN/SAC master Excel files
       - Or use sample data for demonstration
    
    2. **Validate Codes:**
       - Enter individual codes for validation
       - Check hierarchical relationships
    
    3. **Batch Validation:**
       - Validate multiple codes at once
       - Upload text/CSV files with codes
    
    4. **Analytics:**
       - View statistics about your datasets
       - Analyze code length distribution
    """)


if __name__ == "__main__":
    main()